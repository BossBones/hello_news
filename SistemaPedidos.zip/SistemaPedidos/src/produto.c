#include "produto.h"

int criarProduto(PGconn *conn, Produto *p)
{
    const char *sql = "INSERT INTO produto (nome, preco, qtde_produto) VALUES ($1, $2, $3)";
    char precoStr[20], qtdeStr[20];
    snprintf(precoStr, sizeof(precoStr), "%.2f", p->preco);
    snprintf(qtdeStr, sizeof(qtdeStr), "%d", p->qtde_produto);

    const char *paramValues[3];
    paramValues[0] = p->nome;
    paramValues[1] = precoStr;
    paramValues[2] = qtdeStr;

    PGresult *res = PQexecParams(conn, sql, 3, NULL, paramValues, NULL, NULL, 0);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao inserir produto: %s\n", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

int listarProdutos(PGconn *conn)
{
    PGresult *res = PQexec(conn, "SELECT cod_produto, nome, preco, qtde_produto FROM produto ORDER BY cod_produto");
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao listar produtos: %s\n", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    int n = PQntuples(res);
    char *cod, *nome, *preco, *qtde_produto;
    printf("=== Lista de Produtos ===\n");
    for (int i = 0; i < n; i++)
    {
        cod = PQgetvalue(res, i, 0);
        nome = PQgetvalue(res, i, 1);
        preco = PQgetvalue(res, i, 2);
        qtde_produto = PQgetvalue(res, i, 3);
	printf("%s \t| %s \t| %s \t| %s \t\n", cod, preco, nome, qtde_produto);
    }
    if (n == 0)
        printf("Nenhum produto cadastrado.\n");
    PQclear(res);
    return 0;
}

int buscarProdutoPorId(PGconn *conn, int cod, Produto *p)
{
    char sql[200];
    snprintf(sql, sizeof(sql), "SELECT cod_produto, nome, preco, qtde_produto FROM produto WHERE cod_produto = %d", cod);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao buscar produto: %s\n", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    if (PQntuples(res) == 0)
    {
        printf("Produto código %d não encontrado.\n", cod);
        PQclear(res);
        return -1;
    }

    p->cod_produto = atoi(PQgetvalue(res, 0, 0));
    strncpy(p->nome, PQgetvalue(res, 0, 1), 80);
    p->preco = atof(PQgetvalue(res, 0, 2));
    p->qtde_produto = atoi(PQgetvalue(res, 0, 3));
    PQclear(res);
    return 0;
}

int atualizarProduto(PGconn *conn, Produto *p)
{
    char sql[400];
    snprintf(sql, sizeof(sql),
             "UPDATE produto SET nome = '%s', preco = %.2f, qtde_produto = %d WHERE cod_produto = %d",
             p->nome, p->preco, p->qtde_produto, p->cod_produto);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao atualizar produto: %s\n", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

int excluirProduto(PGconn *conn, int cod)
{
    char sql[100];
    snprintf(sql, sizeof(sql), "DELETE FROM produto WHERE cod_produto = %d", cod);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao excluir produto: %s\n", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}
