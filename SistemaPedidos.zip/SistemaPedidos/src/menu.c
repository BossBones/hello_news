#include "menu.h"

void menu(PGconn *conn)
{
    int op = menuPrincipal();
    while (op != 0)
    {
        switch (op)
        {
        case 1:
            menuCliente(conn);
            break;
        case 2:
            menuProduto(conn);
            break;
        case 3:
            menuPedido(conn);
            break;
        }
        op = menuPrincipal();
    }
}
int menuPrincipal()
{
    puts("1 - Cliente");
    puts("2 - Produto");
    puts("3 - Pedido");
    puts("0 - Sair");
    int op;
    puts("Digite a opção desejada: ");
    scanf("%d", &op);
    while (op < 0 || op > 3)
    {
        puts("Opção inválida, digite novamente: ");
        scanf("%d", &op);
    }
    return op;
}
