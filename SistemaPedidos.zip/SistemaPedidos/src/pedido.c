#include "pedido.h"

int criarPedido(PGconn *conn, Pedido *p)
{
    /* Insere com valor total 0, que será atualizado ao incluir itens */
    const char *sql = "INSERT INTO pedido (id_cliente, dt_pedido, dt_entrega, vlr_total) "
                      "VALUES ($1, $2, $3, 0.00)";
    char id_cliente[20], dt_pedido[20], dt_entrega[20];
    snprintf(id_cliente, sizeof(id_cliente), "%d", p->id_cliente);
    snprintf(dt_pedido, sizeof(dt_pedido), "%s", p->dt_pedido);
    snprintf(dt_entrega, sizeof(dt_entrega), "%s", p->dt_entrega);

    const char *paramValues[3] = {id_cliente, dt_pedido, dt_entrega};

    PGresult *res = PQexecParams(conn, sql, 3, NULL, paramValues, NULL, NULL, 0);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao criar pedido: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

int listarPedidos(PGconn *conn)
{
    PGresult *res = PQexec(conn,
                           "SELECT p.cod_pedido, cl.nome AS cliente, p.dt_pedido, p.dt_entrega, p.vlr_total "
                           "FROM pedido p JOIN cliente cl ON p.id_cliente = cl.id_cliente "
                           "ORDER BY p.cod_pedido");
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao listar pedidos: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    int n = PQntuples(res);
    printf("=== Lista de Pedidos ===");
    for (int i = 0; i < n; i++)
    {
        PQgetvalue(res, i, 0);
        PQgetvalue(res, i, 1);
        PQgetvalue(res, i, 2);
        PQgetvalue(res, i, 3);
        PQgetvalue(res, i, 4);
    }
    if (n == 0)
        printf("Nenhum pedido registrado.");
    PQclear(res);
    return 0;
}

int buscarPedidoPorId(PGconn *conn, int cod, Pedido *p)
{
    char sql[300];
    snprintf(sql, sizeof(sql),
             "SELECT cod_pedido, id_cliente, dt_pedido, dt_entrega, vlr_total "
             "FROM pedido WHERE cod_pedido = %d",
             cod);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao buscar pedido: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    if (PQntuples(res) == 0)
    {
        printf("Pedido %d não encontrado.", cod);
        PQclear(res);
        return -1;
    }

    p->cod_pedido = atoi(PQgetvalue(res, 0, 0));
    p->id_cliente = atoi(PQgetvalue(res, 0, 1));
    strncpy(p->dt_pedido, PQgetvalue(res, 0, 2), 10);
    strncpy(p->dt_entrega, PQgetvalue(res, 0, 3), 10);
    p->vlr_total = atof(PQgetvalue(res, 0, 4));
    PQclear(res);
    return 0;
}

int atualizarPedido(PGconn *conn, Pedido *p)
{
    char sql[400];
    snprintf(sql, sizeof(sql),
             "UPDATE pedido SET id_cliente = %d, dt_pedido = '%s', dt_entrega = '%s' "
             "WHERE cod_pedido = %d",
             p->id_cliente, p->dt_pedido, p->dt_entrega, p->cod_pedido);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao atualizar pedido: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

int excluirPedido(PGconn *conn, int cod)
{
    /*
     * Primeiro exclui os itens do pedido (para respeitar a chave estrangeira),
     * depois exclui o pedido.
     */
    char sql[200];

    snprintf(sql, sizeof(sql), "DELETE FROM item WHERE cod_pedido = %d", cod);
    PGresult *res = PQexec(conn, sql);
    PQclear(res);

    snprintf(sql, sizeof(sql), "DELETE FROM pedido WHERE cod_pedido = %d", cod);
    res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao excluir pedido: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}