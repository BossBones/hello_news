#include "menuproduto.h"

void menuIncluirProduto(PGconn *conn);
void menuConsultarProduto(PGconn *conn);
void menuAtualizarProduto(PGconn *conn);
void menuExcluirProduto(PGconn *conn);

void menuProduto(PGconn *conn)
{
    int op = menuCRUD("Produto");
    while (op != 0)
    {
        switch (op)
        {
        case 1:
            menuIncluirProduto(conn);
            break;
        case 2:
            listarProdutos(conn);
            break;
        case 3:
            menuConsultarProduto(conn);
            break;
        case 4:
            menuAtualizarProduto(conn);
            break;
        case 5:
            menuExcluirProduto(conn);
            break;
        }
        op = menuCRUD("Produto");
    }
}
void menuIncluirProduto(PGconn *conn)
{
    Produto p;
    printf("--- Inserir Produto ---\n");
    printf("Nome: ");
    limparBuffer();
    fgets(p.nome, 80, stdin);
    p.nome[strcspn(p.nome, "\n")] = '\0';
    printf("Preço: ");
    scanf("%f", &p.preco);
    printf("Quantidade em estoque: ");
    scanf("%d", &p.qtde_produto);
    if (criarProduto(conn, &p) == 0)
        printf("Produto cadastrado!\n");
}
void menuConsultarProduto(PGconn *conn)
{
    Produto p;
    int cod;
    printf("Código do produto: ");
    limparBuffer();
    scanf("%d", &cod);
    limparBuffer();
    if (buscarProdutoPorId(conn, cod, &p) == 0)
    {
        printf("Dados do produto:");
        printf("Código: %d", p.cod_produto);
        printf("Nome: %s", p.nome);
        printf("Preço: R$ %.2f", p.preco);
        printf("Estoque: %d", p.qtde_produto);
    }
}
void menuAtualizarProduto(PGconn *conn)
{
    Produto p;
    int cod;
    printf("Código do produto a atualizar: ");
    limparBuffer();
    scanf("%d", &cod);
    limparBuffer();
    if (buscarProdutoPorId(conn, cod, &p) == -1)
    {
        puts("Produto não encontrado");
        return;
    }
    printf("Novo nome (atual: %s): ", p.nome);
    limparBuffer();
    fgets(p.nome, 80, stdin);
    p.nome[strcspn(p.nome, "")] = '\0';
    printf("Novo preço (atual: %.2f): ", p.preco);
    limparBuffer();
    scanf("%f", &p.preco);
    printf("Nova quantidade (atual: %d): ", p.qtde_produto);
    limparBuffer();
    scanf("%d", &p.qtde_produto);
    limparBuffer();
    if (atualizarProduto(conn, &p) == 0)
        printf("Produto atualizado!");
}

void menuExcluirProduto(PGconn *conn)
{
    int cod;
    printf("Código do produto a excluir: ");
    limparBuffer();
    scanf("%d", &cod);
    limparBuffer();
    if (excluirProduto(conn, cod) == 0)
        printf("Produto excluído (se não houver itens vinculados).");
}
