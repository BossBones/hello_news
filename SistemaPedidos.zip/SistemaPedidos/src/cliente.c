#include "cliente.h"

/*
 * Função: criarCliente
 * ---------------------
 * Insere um novo cliente no banco de dados.
 *
 * Parâmetros:
 *   conn - Conexão ativa com PostgreSQL (PGconn*)
 *   c    - Ponteiro para estrutura Cliente com os dados preenchidos
 *          (o campo id_cliente é ignorado, pois o banco gera automático)
 *
 * Retorno: 0 sucesso, -1 erro
 *
 * Observação: utiliza prepared statement para evitar SQL Injection.
 */
int criarCliente(PGconn *conn, Cliente *c)
{
    const char *sql = "INSERT INTO cliente (nome) VALUES ($1)";
    const char *paramValues[1];
    paramValues[0] = c->nome;

    PGresult *res = PQexecParams(conn, sql, 1, NULL, paramValues, NULL, NULL, 0);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao inserir cliente: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

/*
 * Função: listarClientes
 * -----------------------
 * Lista todos os clientes cadastrados no banco.
 *
 * Parâmetros:
 *   conn - Conexão ativa
 *
 * Retorno: 0 sucesso, -1 erro
 *
 * Os resultados são exibidos na saída padrão (stdout).
 */
int listarClientes(PGconn *conn)
{
    PGresult *res = PQexec(conn, "SELECT id_cliente, nome FROM cliente ORDER BY id_cliente");
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao listar clientes: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    int nTuples = PQntuples(res);
    printf("=== Lista de Clientes ===");
    char *id, *nome;
    for (int i = 0; i < nTuples; i++)
    {
        id = PQgetvalue(res, i, 0);
        nome = PQgetvalue(res, i, 1);
	// Imprime na tela (ex: "ID: 1 | Nome: João")
	printf("\nID: %s | Nome: %s", id, nome);
    }
    puts("\n");
    if (nTuples == 0)
    {
        printf("Nenhum cliente cadastrado.");
    }
    PQclear(res);
    return 0;
}

/*
 * Função: buscarClientePorId
 * ---------------------------
 * Busca um cliente específico pelo seu ID.
 *
 * Parâmetros:
 *   conn    - Conexão ativa
 *   id      - ID do cliente a ser buscado
 *   cliente - Ponteiro para estrutura que receberá os dados
 *
 * Retorno: 0 se encontrado, -1 se não encontrado ou erro
 */
int buscarClientePorId(PGconn *conn, int id, Cliente *cliente)
{
    char sql[200];
    snprintf(sql, sizeof(sql), "SELECT id_cliente, nome FROM cliente WHERE id_cliente = %d", id);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao buscar cliente: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    if (PQntuples(res) == 0)
    {
        printf("Cliente com ID %d não encontrado.", id);
        PQclear(res);
        return -1;
    }

    cliente->id_cliente = atoi(PQgetvalue(res, 0, 0));
    strncpy(cliente->nome, PQgetvalue(res, 0, 1), 80);
    PQclear(res);
    return 0;
}

/*
 * Função: atualizarCliente
 * -------------------------
 * Atualiza os dados de um cliente existente.
 *
 * Parâmetros:
 *   conn - Conexão ativa
 *   c    - Ponteiro para estrutura com os novos dados (deve conter id_cliente)
 *
 * Retorno: 0 sucesso, -1 erro
 */
int atualizarCliente(PGconn *conn, Cliente *c)
{
    char sql[300];
    snprintf(sql, sizeof(sql),
             "UPDATE cliente SET nome = '%s' WHERE id_cliente = %d",
             c->nome, c->id_cliente);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao atualizar cliente: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

/*
 * Função: excluirCliente
 * -----------------------
 * Exclui um cliente do banco de dados.
 *
 * Parâmetros:
 *   conn - Conexão ativa
 *   id   - ID do cliente a ser excluído
 *
 * Retorno: 0 sucesso, -1 erro
 *
 * Atenção: a exclusão pode falhar se houver pedidos associados ao cliente
 * (violação de chave estrangeira). Nesse caso, a mensagem de erro do PostgreSQL
 * será exibida.
 */
int excluirCliente(PGconn *conn, int id)
{
    char sql[100];
    snprintf(sql, sizeof(sql), "DELETE FROM cliente WHERE id_cliente = %d", id);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao excluir cliente: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}
