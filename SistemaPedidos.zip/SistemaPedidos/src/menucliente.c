#include "menucliente.h"

// Assinaturas de funções
void menuIncluirCliente(PGconn *conn);
void menuConsultarCliente(PGconn *conn);
void menuAtualizarCliente(PGconn *conn);
void menuExcluirCliente(PGconn *conn);

void menuCliente(PGconn *conn)
{
    int op = menuCRUD("Cliente");
    while (op != 0)
    {
        switch (op)
        {
        case 1:
            menuIncluirCliente(conn);
            break;
        case 2:
            listarClientes(conn);
            break;
        case 3:
            menuConsultarCliente(conn);
            break;
        case 4:
            menuAtualizarCliente(conn);
            break;
        case 5:
            menuExcluirCliente(conn);
            break;
        }
        op = menuCRUD("Cliente");
    }
}
void menuIncluirCliente(PGconn *conn)
{
    Cliente c;
    printf("--- Inserir Cliente ---");
    printf("Nome: ");
    limparBuffer();
    fgets(c.nome, 80, stdin);
    c.nome[strcspn(c.nome, "\n")] = '\0';
    if (criarCliente(conn, &c) == 0)
        printf("Cliente cadastrado com sucesso!\n");
}
void menuConsultarCliente(PGconn *conn)
{
    Cliente c;
    int id;
    printf("ID do cliente: ");
    scanf("%d", &id);
    limparBuffer();
    if (buscarClientePorId(conn, id, &c) == 0)
    {
        printf("Dados do cliente:");
        printf("ID: %d", c.id_cliente);
        printf("Nome: %s", c.nome);
    }
}
void menuAtualizarCliente(PGconn *conn)
{
    Cliente c;
    int id;
    printf("ID do cliente a atualizar: ");
    scanf("%d", &id);
    limparBuffer();
    if (buscarClientePorId(conn, id, &c) == -1)
    {
        puts("Cliente não encontrado\n");
        return;
    }
    printf("Novo nome (atual: %s): ", c.nome);
    fgets(c.nome, 80, stdin);
    c.nome[strcspn(c.nome, "")] = '\0';
    if (atualizarCliente(conn, &c) == 0)
        printf("Cliente atualizado!\n");
}

void menuExcluirCliente(PGconn *conn)
{
    int id;
    printf("ID do cliente a excluir: ");
    scanf("%d", &id);
    limparBuffer();
    if (excluirCliente(conn, id) == 0)
        printf("Cliente excluído (se não houver pedidos vinculados).\n");
}
