
#include "menuitem.h"

void menuIncluirItem(PGconn *conn);
void menuConsultarItem(PGconn *conn);
void menuAtualizarItem(PGconn *conn);
void menuExcluirItem(PGconn *conn);

void menuItem(PGconn *conn)
{
    int op = menuCRUD("Item");
    while (op != 0)
    {
        switch (op)
        {
        case 1:
            menuIncluirItem(conn);
            break;
        case 2:
            listarItens(conn);
            break;
        case 3:
            menuConsultarItem(conn);
            break;
        case 4:
            menuAtualizarItem(conn);
            break;
        case 5:
            menuExcluirItem(conn);
            break;
        }
        op = menuCRUD("Item");
    }
}
void menuIncluirItem(PGconn *conn)
{
    Item it;
    printf("--- Inserir Item ---");
    printf("Código do pedido: ");
    scanf("%d", &it.cod_pedido);
    printf("Código do produto: ");
    scanf("%d", &it.cod_produto);
    printf("Quantidade: ");
    scanf("%d", &it.qtde_itens);
    printf("Preço unitário: ");
    scanf("%f", &it.preco_uni_item);
    limparBuffer();
    if (criarItem(conn, &it) == 0)
        printf("Item inserido no pedido %d (seq = %d)!", it.cod_pedido, it.seq_item);
}
void menuConsultarItem(PGconn *conn)
{
    Item it;
    int codPedido, seq;
    printf("Código do pedido: ");
    scanf("%d", &codPedido);
    printf("Sequência do item: ");
    scanf("%d", &seq);
    limparBuffer();
    if (buscarItemPorId(conn, codPedido, seq, &it) == 0)
    {
        printf("Dados do item:");
        printf("Pedido: %d  Seq: %d", it.cod_pedido, it.seq_item);
        printf("Produto: %d", it.cod_produto);
        printf("Quantidade: %d", it.qtde_itens);
        printf("Preço unitário: R$ %.2f", it.preco_uni_item);
        printf("Preço total: R$ %.2f", it.preco_total);
    }
}
void menuAtualizarItem(PGconn *conn)
{
    Item it;
    int codPedido, seq;
    printf("Código do pedido: ");
    scanf("%d", &codPedido);
    printf("Sequência do item: ");
    scanf("%d", &seq);
    limparBuffer();
    if (buscarItemPorId(conn, codPedido, seq, &it) == -1)
    {
        puts("Item não encontrado");
        return;
    }
    printf("Novo código do produto (atual: %d): ", it.cod_produto);
    scanf("%d", &it.cod_produto);
    printf("Nova quantidade (atual: %d): ", it.qtde_itens);
    scanf("%d", &it.qtde_itens);
    printf("Novo preço unitário (atual: %.2f): ", it.preco_uni_item);
    scanf("%f", &it.preco_uni_item);
    limparBuffer();
    if (atualizarItem(conn, &it) == 0)
        printf("Item atualizado!");
}

void menuExcluirItem(PGconn *conn)
{
    int codPedido, seq;
    printf("Código do pedido: ");
    scanf("%d", &codPedido);
    printf("Sequência do item: ");
    scanf("%d", &seq);
    limparBuffer();
    if (excluirItem(conn, codPedido, seq) == 0)
        printf("Item excluído.");
}