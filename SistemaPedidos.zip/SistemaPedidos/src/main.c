/*
 * main.c
 *
 * Arquivo principal do sistema CRUD de Pedidos.
 * Integra todos os módulos (cliente, produto, pedido, item) e
 * fornece menus interativos para o usuário.
 *
 * Para compilar:
 *   gcc -o pedido_crud main.c -I/usr/include/postgresql -lpq
 *
 * Para executar:
 *   ./pedido_crud
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "menu.h"
#include "bdpedido.h"

/*
 * Função principal
 *  */

int main()
{
    printf("=== SISTEMA DE PEDIDOS - Banco de Dados 'Pedido' ===\n");

    PGconn *conn = conectarBanco();
    if (conn == NULL)
    {
        printf("Não foi possível conectar ao banco. Verifique a string de conexão.\n");
        return 1;
    }

    menu(conn);

    /* Fecha a conexão com o banco */
    PQfinish(conn);
    printf("Conexão encerrada. Até logo!\n");
    return 0;
}
