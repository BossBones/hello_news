#include "item.h"

/*
 * Função auxiliar: recalcularTotalPedido
 * ---------------------------------------
 * Atualiza o campo vlr_total do pedido somando o preco_total de todos os itens.
 *
 * Parâmetros:
 *   conn       - Conexão ativa
 *   cod_pedido - Código do pedido a ser recalculado
 *
 * Retorno: 0 sucesso, -1 erro
 *
 * Esta função é chamada automaticamente após inserir, alterar ou excluir itens.
 */
static int recalcularTotalPedido(PGconn *conn, int cod_pedido)
{
    char sql[300];
    snprintf(sql, sizeof(sql),
             "UPDATE pedido SET vlr_total = (SELECT COALESCE(SUM(preco_total), 0) "
             "FROM item WHERE cod_pedido = %d) WHERE cod_pedido = %d",
             cod_pedido, cod_pedido);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao recalcular total do pedido: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return 0;
}

int criarItem(PGconn *conn, Item *it)
{
    /*
     * Verifica a próxima sequência disponível para este pedido
     */
    char sql[200];
    snprintf(sql, sizeof(sql),
             "SELECT COALESCE(MAX(seq_item), 0) + 1 FROM item WHERE cod_pedido = %d",
             it->cod_pedido);
    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao obter sequência: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    it->seq_item = atoi(PQgetvalue(res, 0, 0));
    PQclear(res);

    /* Calcula o preço total do item */
    it->preco_total = it->qtde_itens * it->preco_uni_item;

    /* Prepara os parâmetros */
    char codPedido[20], seqItem[20], codProduto[20], qtde[20], precoUni[20], precoTot[20];
    snprintf(codPedido, sizeof(codPedido), "%d", it->cod_pedido);
    snprintf(seqItem, sizeof(seqItem), "%d", it->seq_item);
    snprintf(codProduto, sizeof(codProduto), "%d", it->cod_produto);
    snprintf(qtde, sizeof(qtde), "%d", it->qtde_itens);
    snprintf(precoUni, sizeof(precoUni), "%.2f", it->preco_uni_item);
    snprintf(precoTot, sizeof(precoTot), "%.2f", it->preco_total);

    const char *paramValues[6] = {codPedido, seqItem, codProduto, qtde, precoUni, precoTot};
    const char *sqlInsert = "INSERT INTO item (cod_pedido, seq_item, cod_produto, qtde_itens, preco_uni_item, preco_total) "
                            "VALUES ($1, $2, $3, $4, $5, $6)";

    res = PQexecParams(conn, sqlInsert, 6, NULL, paramValues, NULL, NULL, 0);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao inserir item: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);

    /* Recalcula o total do pedido */
    return recalcularTotalPedido(conn, it->cod_pedido);
}

int listarItens(PGconn *conn)
{
    PGresult *res = PQexec(conn,
                           "SELECT i.cod_pedido, i.seq_item, i.cod_produto, p.nome AS produto, "
                           "i.qtde_itens, i.preco_uni_item, i.preco_total "
                           "FROM item i JOIN produto p ON i.cod_produto = p.cod_produto "
                           "ORDER BY i.cod_pedido, i.seq_item");
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao listar itens: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    int n = PQntuples(res);
    printf("=== Lista de Itens ===");
    for (int i = 0; i < n; i++)
    {
        PQgetvalue(res, i, 0);
        PQgetvalue(res, i, 1);
        PQgetvalue(res, i, 2);
        PQgetvalue(res, i, 3);
        PQgetvalue(res, i, 4);
        PQgetvalue(res, i, 5);
        PQgetvalue(res, i, 6);
    }
    if (n == 0)
        printf("Nenhum item cadastrado.");
    PQclear(res);
    return 0;
}

int buscarItemPorId(PGconn *conn, int cod_pedido, int seq_item, Item *it)
{
    char sql[300];
    snprintf(sql, sizeof(sql),
             "SELECT cod_pedido, seq_item, cod_produto, qtde_itens, preco_uni_item, preco_total "
             "FROM item WHERE cod_pedido = %d AND seq_item = %d",
             cod_pedido, seq_item);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_TUPLES_OK)
    {
        fprintf(stderr, "Erro ao buscar item: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }

    if (PQntuples(res) == 0)
    {
        printf("Item não encontrado.");
        PQclear(res);
        return -1;
    }

    it->cod_pedido = atoi(PQgetvalue(res, 0, 0));
    it->seq_item = atoi(PQgetvalue(res, 0, 1));
    it->cod_produto = atoi(PQgetvalue(res, 0, 2));
    it->qtde_itens = atoi(PQgetvalue(res, 0, 3));
    it->preco_uni_item = atof(PQgetvalue(res, 0, 4));
    it->preco_total = atof(PQgetvalue(res, 0, 5));
    PQclear(res);
    return 0;
}

int atualizarItem(PGconn *conn, Item *it)
{
    /* Recalcula o preço total */
    it->preco_total = it->qtde_itens * it->preco_uni_item;

    char sql[500];
    snprintf(sql, sizeof(sql),
             "UPDATE item SET cod_produto = %d, qtde_itens = %d, "
             "preco_uni_item = %.2f, preco_total = %.2f "
             "WHERE cod_pedido = %d AND seq_item = %d",
             it->cod_produto, it->qtde_itens,
             it->preco_uni_item, it->preco_total,
             it->cod_pedido, it->seq_item);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao atualizar item: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return recalcularTotalPedido(conn, it->cod_pedido);
}

int excluirItem(PGconn *conn, int cod_pedido, int seq_item)
{
    char sql[200];
    snprintf(sql, sizeof(sql),
             "DELETE FROM item WHERE cod_pedido = %d AND seq_item = %d",
             cod_pedido, seq_item);

    PGresult *res = PQexec(conn, sql);
    if (PQresultStatus(res) != PGRES_COMMAND_OK)
    {
        fprintf(stderr, "Erro ao excluir item: %s", PQerrorMessage(conn));
        PQclear(res);
        return -1;
    }
    PQclear(res);
    return recalcularTotalPedido(conn, cod_pedido);
}