/*
 * conectarBanco
 * -------------
 * Estabelece a conexão com o PostgreSQL.
 *
 * IMPORTANTE: ajuste a string de conexão conforme seu ambiente.
 *
 * Parâmetros: nenhum
 * Retorno: PGconn* (NULL em caso de erro)
 */

#include "bdpedido.h"

PGconn *conectarBanco()
{
    /*
     * Altere "host", "port", "dbname", "user" e "password" conforme necessário.
     * Exemplo de conexão local:
     *   "host=localhost port=5432 dbname=pedido user=postgres password=123"
     */
    const char *connInfo = "host=localhost port=5432 dbname=pedidos user=postgres password=segredo";
    PGconn *conn = PQconnectdb(connInfo);

    if (PQstatus(conn) != CONNECTION_OK)
    {
        fprintf(stderr, "Erro ao conectar ao banco: %s\n", PQerrorMessage(conn));
        PQfinish(conn);
        return NULL;
    }
    printf("Conectado ao banco de dados 'pedido' com sucesso!\n");
    return conn;
}
