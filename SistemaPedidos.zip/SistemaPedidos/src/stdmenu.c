#include "stdmenu.h"

void limparBuffer()
{
    int c;
    while ((c = getchar()) != '\n' && c != EOF)
        ;
}

int menuCRUD(char *tabela)
{
    printf("1 - Incluir %s\n", tabela);
    printf("2 - Listar %s\n", tabela);
    printf("3 - Consultar %s\n", tabela);
    printf("4 - Atualizar %s\n", tabela);
    printf("5 - Excluir %s\n", tabela);
    printf("0 - Voltar");
    int op;
    puts("Digite a opção desejada: ");
    scanf("%d", &op);
    while (op < 0 || op > 5)
    {
        puts("Opção inválida, digite novamente: ");
        scanf("%d", &op);
    }
    return op;
}