#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "stdmenu.h"
#include "pedido.h"

void menuIncluirPedido(PGconn *conn);
void menuConsultarPedido(PGconn *conn);
void menuAtualizarPedido(PGconn *conn);
void menuExcluirPedido(PGconn *conn);

void menuPedido(PGconn *conn)
{
    int op = menuCRUD("Pedido");
    while (op != 0)
    {
        switch (op)
        {
        case 1:
            menuIncluirPedido(conn);
            break;
        case 2:
            listarPedidos(conn);
            break;
        case 3:
            menuConsultarPedido(conn);
            break;
        case 4:
            menuAtualizarPedido(conn);
            break;
        case 5:
            menuExcluirPedido(conn);
            break;
        }
        op = menuCRUD("Pedido");
    }
}
void menuIncluirPedido(PGconn *conn)
{
    Pedido ped;
    printf("--- Inserir Pedido ---");
    printf("ID do Cliente: ");
    scanf("%d", &ped.id_cliente);
    limparBuffer();
    printf("Data do pedido (YYYY-MM-DD): ");
    fgets(ped.dt_pedido, 10, stdin);
    ped.dt_pedido[strcspn(ped.dt_pedido, "")] = '\0';
    printf("Data de entrega (YYYY-MM-DD): ");
    fgets(ped.dt_entrega, 10, stdin);
    ped.dt_entrega[strcspn(ped.dt_entrega, "\n")] = '\0';
    if (criarPedido(conn, &ped) == 0)
        printf("Pedido criado!");
}
void menuConsultarPedido(PGconn *conn)
{
    Pedido ped;
    int cod;
    printf("Código do pedido: ");
    scanf("%d", &cod);
    limparBuffer();
    if (buscarPedidoPorId(conn, cod, &ped) == 0)
    {
        printf("Dados do pedido:");
        printf("Código: %d", ped.cod_pedido);
        printf("Cliente ID: %d", ped.id_cliente);
        printf("Data pedido: %s", ped.dt_pedido);
        printf("Data entrega: %s", ped.dt_entrega);
        printf("Valor total: R$ %.2f", ped.vlr_total);
    }
}
void menuAtualizarPedido(PGconn *conn)
{
    Pedido ped;
    int cod;
    printf("Código do pedido a atualizar: ");
    scanf("%d", &cod);
    limparBuffer();
    if (buscarPedidoPorId(conn, cod, &ped) == -1)
    {
        puts("Pedido não encontrado");
        return;
    }
    printf("Novo ID do cliente (atual: %d): ", ped.id_cliente);
    scanf("%d", &ped.id_cliente);
    limparBuffer();
    printf("Nova data do pedido (atual: %s): ", ped.dt_pedido);
    fgets(ped.dt_pedido, 10, stdin);
    ped.dt_pedido[strcspn(ped.dt_pedido, "")] = '\0';
    printf("Nova data de entrega (atual: %s): ", ped.dt_entrega);
    fgets(ped.dt_entrega, 10, stdin);
    ped.dt_entrega[strcspn(ped.dt_entrega, "")] = '\0';
    if (atualizarPedido(conn, &ped) == 0)
        printf("Pedido atualizado!");
}

void menuExcluirPedido(PGconn *conn)
{
    int cod;
    printf("Código do pedido a excluir: ");
    scanf("%d", &cod);
    limparBuffer();
    if (excluirPedido(conn, cod) == 0)
        printf("Pedido e seus itens excluídos.");
}
