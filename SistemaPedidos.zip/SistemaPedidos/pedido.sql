DROP TABLE IF EXISTS cliente CASCADE;
DROP TABLE IF EXISTS produto CASCADE;
DROP TABLE IF EXISTS pedido CASCADE;
DROP TABLE IF EXISTS item CASCADE;
CREATE TABLE cliente(
    id_cliente SERIAL PRIMARY KEY CHECK(id_cliente > 0),
    nome VARCHAR(80) NOT NULL
);
CREATE TABLE produto(
    cod_produto SERIAL PRIMARY KEY CHECK(cod_produto > 0),
    nome VARCHAR(80) NOT NULL,
    preco FLOAT NOT NULL CHECK(preco >= 0),
    qtde_produto INTEGER NOT NULL CHECK(qtde_produto >= 0)
);
CREATE TABLE pedido(
    cod_pedido SERIAL PRIMARY KEY CHECK(cod_pedido > 0),
    id_cliente INTEGER REFERENCES cliente ON DELETE RESTRICT NOT NULL CHECK(id_cliente > 0),
    dt_pedido DATE NOT NULL DEFAULT(CURRENT_DATE),
    dt_entrega DATE,
    vlr_total FLOAT NOT NULL CHECK(vlr_total > 0)
);
CREATE TABLE item(
    cod_pedido INTEGER REFERENCES pedido ON DELETE CASCADE NOT NULL CHECK(cod_pedido > 0),
    seq_item SERIAL NOT NULL CHECK(seq_item > 0),
    cod_produto INTEGER REFERENCES produto ON DELETE RESTRICT NOT NULL CHECK(cod_produto > 0),
    qtde_itens INTEGER NOT NULL CHECK(qtde_itens > 0),
    preco_uni_item FLOAT NOT NULL CHECK(preco_uni_item >= 0),
    preco_total FLOAT NOT NULL CHECK(preco_total >= 0),
    PRIMARY KEY(cod_pedido, seq_item)
);
