#ifndef MENUCLIENTE_H
#define MENUCLIENTE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "stdmenu.h"
#include "cliente.h"

void menuCliente(PGconn *conn);
void menuIncluirCliente(PGconn *conn);
void menuConsultarCliente(PGconn *conn);
void menuAtualizarCliente(PGconn *conn);
void menuExcluirCliente(PGconn *conn);

#endif