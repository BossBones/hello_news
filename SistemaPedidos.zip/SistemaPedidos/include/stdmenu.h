#ifndef STDMENU_H
#define STDMENU_H

#include <stdio.h>
#include <stdlib.h>
void limparBuffer();
int menuCRUD(char *tabela);

#endif