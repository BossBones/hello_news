#ifndef STDMENU_H
#define STDMENU_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "menucliente.h"
#include "menuitem.h"
#include "menupedido.h"
#include "menuproduto.h"

void menu(PGconn *conn);
int menuPrincipal();

#endif
