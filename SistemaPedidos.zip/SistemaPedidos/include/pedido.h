/*
 * pedido.h
 *
 * Módulo de CRUD para a tabela "pedido".
 * Tabela: pedido (cod_pedido serial, id_cliente integer,
 *                 dt_pedido date, dt_entrega date, vlr_total numeric(12,2))
 */

#ifndef PEDIDO_H
#define PEDIDO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <postgresql/libpq-fe.h>

/*
 * Estrutura Pedido
 */
typedef struct
{
    int cod_pedido;      /* Código do pedido (gerado automaticamente) */
    int id_cliente;      /* Referência ao cliente */
    char dt_pedido[11];  /* Data do pedido (formato: YYYY-MM-DD) */
    char dt_entrega[11]; /* Data prevista de entrega */
    float vlr_total;     /* Valor total do pedido (calculado pelos itens) */
} Pedido;

int criarPedido(PGconn *conn, Pedido *p);
int listarPedidos(PGconn *conn);
int buscarPedidoPorId(PGconn *conn, int cod, Pedido *p);
int atualizarPedido(PGconn *conn, Pedido *p);
int excluirPedido(PGconn *conn, int cod);

#endif /* PEDIDO_H */