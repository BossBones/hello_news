#ifndef MENUITEM_H
#define MENUITEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "stdmenu.h"
#include "item.h"

void menuItem(PGconn *conn);
void menuIncluirItem(PGconn *conn);
void menuConsultarItem(PGconn *conn);
void menuAtualizarItem(PGconn *conn);
void menuExcluirItem(PGconn *conn);

#endif