#ifndef MENUPRODUTO_H
#define MENUPRODUTO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "stdmenu.h"
#include "produto.h"

void menuProduto(PGconn *conn);
void menuIncluirProduto(PGconn *conn);
void menuConsultarProduto(PGconn *conn);
void menuAtualizarProduto(PGconn *conn);
void menuExcluirProduto(PGconn *conn);

#endif
