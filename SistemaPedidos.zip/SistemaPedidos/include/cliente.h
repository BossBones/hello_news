/*
 * cliente.h
 *
 * Módulo responsável pelas operações CRUD da tabela "cliente".
 * Tabela: cliente (id_cliente serial, nome varchar(80))
 *
 * Todas as funções recebem uma conexão ativa com o banco (PGconn*)
 * e retornam 0 em caso de sucesso ou -1 em caso de erro.
 */

#ifndef CLIENTE_H
#define CLIENTE_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <postgresql/libpq-fe.h>

/*
 * Estrutura que represenfta um cliente.
 * Corresponde diretamente aos campos da tabela cliente.
 */
typedef struct
{
    int id_cliente; /* Identificador único (gerado pelo banco) */
    char nome[81];  /* Nome do cliente (80 caracteres + \0) */
} Cliente;

int criarCliente(PGconn *conn, Cliente *c);
int listarClientes(PGconn *conn);
int buscarClientePorId(PGconn *conn, int id, Cliente *cliente);
int atualizarCliente(PGconn *conn, Cliente *c);
int excluirCliente(PGconn *conn, int id);

#endif /* CLIENTE_H */