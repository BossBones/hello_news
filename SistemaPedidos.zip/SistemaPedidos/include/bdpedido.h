

/*
 * conectarBanco
 * -------------
 * Estabelece a conexão com o PostgreSQL.
 *
 * IMPORTANTE: ajuste a string de conexão conforme seu ambiente.
 *
 * Parâmetros: nenhum<br/>
 * Retorno: PGconn* (NULL em caso de erro)
 */
#ifndef BDPEDIDO_H
#define BDPEDIDO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <postgresql/libpq-fe.h>

PGconn *conectarBanco();

#endif