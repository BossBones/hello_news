#ifndef MENUPEDIDO_H
#define MENUPEDIDO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include <postgresql/libpq-fe.h>

#include "stdmenu.h"
#include "pedido.h"

void menuPedido(PGconn *conn);
void menuIncluirPedido(PGconn *conn);
void menuConsultarPedido(PGconn *conn);
void menuAtualizarPedido(PGconn *conn);
void menuExcluirPedido(PGconn *conn);

#endif