/*
 * item.h
 *
 * Módulo de CRUD para a tabela "item" (itens do pedido).
 * Tabela: item (cod_pedido integer, seq_item integer,
 *               cod_produto integer, qtde_itens integer,
 *               preco_uni_item decimal(10,2), preco_total decimal(10,2))
 */

#ifndef ITEM_H
#define ITEM_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <postgresql/libpq-fe.h>

/*
 * Estrutura Item
 */
typedef struct
{
    int cod_pedido;       /* Código do pedido (chave estrangeira) */
    int seq_item;         /* Sequência do item dentro do pedido */
    int cod_produto;      /* Código do produto */
    int qtde_itens;       /* Quantidade comprada */
    float preco_uni_item; /* Preço unitário no momento da compra */
    float preco_total;    /* Quantidade * preco_uni_item (calculado) */
} Item;

int criarItem(PGconn *conn, Item *it);
int listarItens(PGconn *conn);
int buscarItemPorId(PGconn *conn, int cod_pedido, int seq_item, Item *it);
int atualizarItem(PGconn *conn, Item *it);
int excluirItem(PGconn *conn, int cod_pedido, int seq_item);

#endif /* ITEM_H */