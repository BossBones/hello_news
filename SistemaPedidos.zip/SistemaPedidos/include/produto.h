/*
 * produto.h
 *
 * Módulo de CRUD para a tabela "produto".
 * Tabela: produto (cod_produto serial, nome varchar(80), preco decimal(10,2),
 *                  qtde_produto integer)
 */

#ifndef PRODUTO_H
#define PRODUTO_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <postgresql/libpq-fe.h>

/*
 * Estrutura Produto
 * Representa um item do estoque.
 */
typedef struct
{
    int cod_produto;  /* Código do produto (chave primária) */
    char nome[81];    /* Nome do produto (80 caracteres + \0) */
    float preco;      /* Preço unitário atual */
    int qtde_produto; /* Quantidade em estoque */
} Produto;

int criarProduto(PGconn *conn, Produto *p);
int listarProdutos(PGconn *conn);
int buscarProdutoPorId(PGconn *conn, int cod, Produto *p);
int atualizarProduto(PGconn *conn, Produto *p);
int excluirProduto(PGconn *conn, int cod);

#endif /* PRODUTO_H */